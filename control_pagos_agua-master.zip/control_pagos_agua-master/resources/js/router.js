import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
	mode: 'history',
	scrollBehavior() {
		return {x:0, y:0}
	},
	linkActiveClass: 'active',
 	//linkExactActiveClass: 'exact-active',
	routes: [
	{
		path: '/home',
		name: 'home',
		component: require('./components/HomeComponent').default,
		meta: { title: 'Home'}
	},
	{
		path: '/roles/',
		component: require('./components/RouterViewComponent').default,
		children: [
		{
			path: '',
			name: 'roles.index',
			component: require('./components/roles/IndexComponent').default,
			meta: { title: 'Listado de roles' }
		},
		{
			path: ':id/show',
			name: 'roles.show',
			component: require('./components/roles/ShowComponent').default,
			meta: { title: 'Detalle de rol' }
		},
		{
			path: ':id/edit',
			name: 'roles.edit',
			component: require('./components/roles/EditComponent').default,
			meta: { title: 'Modificar rol' }
		},
		]
	}
	/*{
		path: '/admin',
		component: require('./components/admin/RouterViewComponent').default,
		children: [
		{
			path: 'roles',
			name: 'admin.roles',
			component: require('./components/admin/roles/IndexComponent').default,
			meta: { title: 'Roles del sistema' }
		},
		{
			path: 'permissions',
			name: 'admin.permissions',
			component: require('./components/admin/permissions/IndexComponent').default,
			meta: { title: 'Permisos del sistema' }
		},
		{
			path: 'users',
			name: 'admin.users',
			component: require('./components/admin/users/IndexComponent').default,
			meta: { title: 'Usuarios del sistema' }
		},
		{
			path: 'posts',
			name: 'admin.posts',
			component: require('./components/admin/posts/IndexComponent').default,
			meta: { title: 'Posts del sistema' }
		}
		]
	},
	{
		path: '/user/profile',
		name: 'user.profile',
		component: require('./components/user/ProfileComponent').default,
		meta: { title: 'Perfil de usuario' }
	},
	{
		path: '/suspensiones',
		component: require('./components/RouterViewComponent').default,
		children: [
		{
			path: 'empresas',
			name: 'suspensiones.empresas',
			component: require('./components/suspensiones/empresas/IndexComponent').default,
			meta: { title: 'Empresas' }
		},
		{
			path: 'reenviar-encuestas',
			name: 'suspensiones.reenviar-encuestas',
			component: require('./components/suspensiones/encuestas/ReenviarEncuestasComponent').default,
			meta: { title: 'Reenviar encuestas' }
		}
		]
	},*/
	]
})
