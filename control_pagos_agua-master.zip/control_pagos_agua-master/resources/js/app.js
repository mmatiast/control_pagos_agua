/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue');

/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// const files = require.context('./', true, /\.vue$/i)
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default))

Vue.component('example-component', require('./components/ExampleComponent.vue').default);

/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

import router from './router';
import store from './vuex';
import es from 'vee-validate/dist/locale/es';
import VeeValidate from 'vee-validate';
import { Validator } from 'vee-validate';

router.beforeEach((to, from, next) => {
	document.title = to.meta.title
 	next()
});

Vue.use(VeeValidate, {
	classes: true,
	classNames: {
		valid: '',
		invalid: 'is-invalid'
	}
});
Validator.localize('es', es);


const app = new Vue({
	el: '#wrapper',
	router,
	store,
	mounted() {
		this.getUser(this.setUser)
		$('.logout').click(function() {
			this.logout()
		}.bind(this))
	},
	methods: {
		getUser(callback) {
			axios.get('/api/user').then(response => {
				callback(response.data)
			})
			.catch(error => {
				console.log(error)
			})
		},
		setUser(response) {
			this.$store.commit('setUser', response)
		},
		logout() {
			Swal.fire({
				title: 'Cerrar sesión',
				html: `¿Desea cerrar su sesión?`,
				icon: 'warning',
				target: 'page-wrapper',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: '<i class="fa fa-sign-out fa-lg mr-2"></i>Si',
				cancelButtonText: '<i class="fa fa-times fa-lg mr-2"></i>No'
			})
			.then(result => {
				if(result.value) {
					axios.post('/logout')
					.then(response => {
						Swal.fire({
							title: 'Información',
							html: 'Su sesión ha sido finalizada exitosamente',
							icon: 'success',
						})
						.then(result  => {
							location.href = '/'
						})
					})
					.catch(error => {
						console.log(error)
					})
				}
			})
		}
	}
});
