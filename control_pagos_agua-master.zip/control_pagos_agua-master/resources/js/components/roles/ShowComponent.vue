<template>
	<div class="content-wrapper">
		<div class="content-header">
			<div class="container-fluid">
				<div class="row mb-2">
					<div class="col-sm-6">
						<h1 class="m-0 text-dark">Detalle de rol</h1>
					</div>
					<div class="col-sm-6">
						<ol class="breadcrumb float-sm-right">
							<li class="breadcrumb-item">
								<router-link to="/roles">
									Roles
								</router-link>
							</li>
							<li class="breadcrumb-item active">
								{{this.$route.params.id}}
							</li>
						</ol>
					</div>
				</div>
			</div>
		</div>
		<div class="content">
			<div class="card">
				<div class="card-body">
					<h3 class="text-primary">
						Rol {{role.id}}
					</h3>
					<label for="">Nombre</label>: {{role.role}} <br>
					<label for="">Creado</label>: {{role.created_at}} <br>
					<label for="">Actualizado</label>: {{role.updated_at}}
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				role: {}
			}
		},
		mounted() {
			axios.get('/api/roles/'+this.$route.params.id)
			.then(response => {
				this.role = response.data
			})
		}
	}
</script>