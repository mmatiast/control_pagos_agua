<template>
	<div class="content-wrapper">
		<div class="content-header">
			<div class="container-fluid">
				<div class="row mb-2">
					<div class="col-sm-6">
						<h1 class="m-0 text-dark">Roles</h1>
					</div>
					<div class="col-sm-6">
						<ol class="breadcrumb float-sm-right">
							<li class="breadcrumb-item active">Roles</li>
						</ol>
					</div>
				</div>
			</div>
		</div>
		<div class="content">
			<div class="card">
				<div class="card-header">
					<h3 class="card-title">Roles</h3>

					<div class="card-tools">
						<div class="input-group input-group-sm">
							<input type="text" name="table_search" class="form-control float-right" placeholder="Búscar por nombre">

							<div class="input-group-append">
								<button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
							</div>
						</div>
					</div>
				</div>
				<div class="card-body table-responsive p-0">
					<table class="table table-hover text-nowrap" id="table">
						<thead>
							<tr>
								<th>ID</th>
								<th>Role</th>
								<th>Estado</th>
								<th>Acciones</th>
							</tr>
						</thead>
						<tbody>
							<tr v-for="(role, index) of roles.data">
								<td>{{role.id}}</td>
								<td>{{role.role}}</td>
								<td>
									<span class="badge badge-success" v-show="role.deleted_at == null">
										Activo
									</span>
									<span class="badge badge-danger" v-show="role.deleted_at != null">
										Eliminado
									</span>
								</td>
								<td>
									<router-link class="btn btn-primary btn-sm" :to="{name: 'roles.show', params: {id: role.id}}">
										<i class="fas fa-eye"></i>
									</router-link>
									<router-link class="btn btn-primary btn-sm" :to="{name: 'roles.edit', params: {id: role.id}}">
										<i class="fas fa-edit"></i>
									</router-link>
									<button class="delete btn btn-danger btn-sm" v-bind:data-id="role.id" v-bind:data-index="index">
										<i class="fas fa-trash"></i>
									</button>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	export default {
		data() {
			return {
				roles: [],
				role_temp: {},
				index: 0
			}
		},
		mounted() {
			axios.get('/api/roles')
			.then(response => {
				this.roles = response.data
			})

			$('#table tbody').on('click', 'button.delete', function(event) {
				this.index = event.currentTarget.dataset.index
				this.role_temp = this.roles.data[this.index]
				axios.delete('/api/roles/'+this.role_temp.id)
				.then(response => {
					Swal.fire({
						title: 'Rol eliminado',
						html: 'El rol '+ this.role_temp.id + ' fue eliminado correctamente',
						icon: 'warning'
					})
					.then(result => {
						if(result.value) {
							console.log(this.roles.data.splice(this.index))
						}
					})
				})
			}.bind(this))
		}
	}
</script>