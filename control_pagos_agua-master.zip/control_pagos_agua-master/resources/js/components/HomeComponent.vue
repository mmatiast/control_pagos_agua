<template>
	<div class="content-wrapper">
		<div class="content-header">
			<div class="container-fluid">
				<div class="row mb-2">
					<div class="col-sm-6">
						<h1 class="m-0 text-dark">Inicio</h1>
					</div>
					<div class="col-sm-6">
						<ol class="breadcrumb float-sm-right">
							<li class="breadcrumb-item active">Home</li>
						</ol>
					</div>
				</div>
			</div>
		</div>
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-12 col-sm-6 col-md-3">
						<div class="info-box">
							<span class="info-box-icon bg-info elevation-1">
								<i class="fas fa-store-alt"></i>
							</span>
							<div class="info-box-content">
								<span class="info-box-text">
									Empresas registradas
								</span>
								<span class="info-box-number">{{ estadistica.empresas_registradas }}</span>
							</div>
						</div>
					</div>
					<div class="col-12 col-sm-6 col-md-3">
						<div class="info-box mb-3">
							<span class="info-box-icon bg-danger elevation-1"><i class="fas fa-thumbs-down"></i></span>
							<div class="info-box-content">
								<span class="info-box-text">Empresas rechazadas</span>
								<span class="info-box-number">{{ estadistica.empresas_rechazadas }}</span>
							</div>
						</div>
					</div>
					<div class="clearfix hidden-md-up"></div>
					<div class="col-12 col-sm-6 col-md-3">
						<div class="info-box mb-3">
							<span class="info-box-icon bg-success elevation-1">
								<i class="fas fa-users"></i>
							</span>
							<div class="info-box-content">
								<span class="info-box-text">
									Empleados registrados
								</span>
								<span class="info-box-number">{{ estadistica.empleados_registrados }}</span>
							</div>
						</div>
					</div>
					<div class="col-12 col-sm-6 col-md-3">
						<div class="info-box mb-3">
							<span class="info-box-icon bg-warning elevation-1"><i class="fas fa-users-slash"></i></span>
							<div class="info-box-content">
								<span class="info-box-text">Empleados sin resolución</span>
								<span class="info-box-number">{{ estadistica.empleados_sin_resolucion }}</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	export default {
		data() {
			return {
				estadistica: {
					empresas_registradas: 0,
					empresas_rechazadas: 0,
					empleados_registrados: 0,
					empleados_sin_resolucion: 0
				}
			}
		},
		mounted() {			
			this.obtenerCantidadDeRegistros('empresas')
			this.obtenerCantidadDeRegistros('empleados')
			this.obtenerCantidadDeRegistrosConCondicion('empresas', 'estado_definitivo_mineco', 'R')
			this.obtenerCantidadDeRegistrosConCondicion('empleados', 'numero_resolucion_mintrabajo', null)
		},
		methods: {
			obtenerCantidadDeRegistros(tabla) {
				axios.get('/api/estadistica/conteo/'+ tabla)
				.then(response => {
					if(tabla == 'empresas') {
						this.estadistica.empresas_registradas = Intl.NumberFormat('es-GT').format(response.data)
					} else if(tabla == 'empleados') {
						this.estadistica.empleados_registrados = Intl.NumberFormat('es-GT').format(response.data)
					}
				})
			},
			obtenerCantidadDeRegistrosConCondicion(tabla, columna, valor) {
				axios.get(`/api/estadistica/conteo/${tabla}/${columna}/${valor}`)
				.then(response => {
					if(tabla == 'empresas') {
						this.estadistica.empresas_rechazadas = Intl.NumberFormat('es-GT').format(response.data)
					} else if(tabla == 'empleados') {
						this.estadistica.empleados_sin_resolucion = Intl.NumberFormat('es-GT').format(response.data)
					}
				})
			}
		}
	}
</script>