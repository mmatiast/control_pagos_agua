<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\UpdateRoleRequest;
use App\Role;
use DB;

class RoleController extends Controller
{
    public function index(Request $request)
    {
    	return response()->json(DB::table('roles')->select('id', 'role')->orderBy('id')->paginate(10), 200);
    }

    public function show($id)
    {
    	return response()->json(DB::table('roles')->where('id', $id)->first(), 200);
    }

    public function update(UpdateRoleRequest $request, $id)
    {
    	$role = Role::find($id);
        $role->role = $request->role;
        $role->save();
        return response()->json($role, 200);
    }

    public function delete($id)
    {
    	# code...
    }
}
