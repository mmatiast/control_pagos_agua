<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FormaPago extends Model
{
    protected $fillable = [
    	'forma_pago'
    ];
}
