<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePagosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pagos', function (Blueprint $table) {
            $table->id();
            $table->date('fecha_deposito');
            $table->string('numero_deposito');
            $table->double('monto_deposito', 10, 2);
            $table->string('deposito')->nullable()->comment('Foto del comprobante de depósito');
            $table->unsignedBigInteger('cliente_id');
            $table->unsignedBigInteger('recibo_id');
            $table->unsignedBigInteger('banco_id');
            $table->unsignedBigInteger('forma_pago_id');
            $table->unsignedBigInteger('user_id')->comment('Usuario que registró el pago');
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('cliente_id')->references('id')->on('clientes');
            $table->foreign('recibo_id')->references('id')->on('recibos');
            $table->foreign('banco_id')->references('id')->on('bancos');
            $table->foreign('forma_pago_id')->references('id')->on('forma_pagos');
            $table->foreign('user_id')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pagos');
    }
}
